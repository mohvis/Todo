// Dashboard functionality
document.addEventListener('DOMContentLoaded', function() {
    // Initialize Feather icons
    if (typeof feather !== 'undefined') {
        feather.replace();
    }

    // Mobile menu toggle
    const mobileMenuBtn = document.querySelector('[data-mobile-menu]');
    const sidebar = document.querySelector('aside');
    
    if (mobileMenuBtn && sidebar) {
        mobileMenuBtn.addEventListener('click', () => {
            sidebar.classList.toggle('open');
        });
    }

    // Close sidebar when clicking outside on mobile
    document.addEventListener('click', (e) => {
        if (window.innerWidth < 1024 && sidebar && sidebar.classList.contains('open')) {
            if (!sidebar.contains(e.target) && !mobileMenuBtn?.contains(e.target)) {
                sidebar.classList.remove('open');
            }
        }
    });

    // Search functionality
    const searchInput = document.querySelector('input[type="text"]');
    if (searchInput) {
        searchInput.addEventListener('focus', () => {
            searchInput.parentElement.classList.add('ring-2', 'ring-primary-500/20');
        });
        
        searchInput.addEventListener('blur', () => {
            searchInput.parentElement.classList.remove('ring-2', 'ring-primary-500/20');
        });
    }

    // Animate stats on scroll
    const stats = document.querySelectorAll('[data-stat]');
    const animateStats = () => {
        stats.forEach(stat => {
            const rect = stat.getBoundingClientRect();
            if (rect.top < window.innerHeight && rect.bottom > 0) {
                stat.classList.add('animate-pulse-glow');
            }
        });
    };

    window.addEventListener('scroll', animateStats);
    animateStats();

    // Progress bar animation
    const progressBars = document.querySelectorAll('[data-progress]');
    progressBars.forEach(bar => {
        const width = bar.getAttribute('data-progress');
        setTimeout(() => {
            bar.style.width = width + '%';
        }, 300);
    });

    // Card hover effects
    const cards = document.querySelectorAll('.group');
    cards.forEach(card => {
        card.addEventListener('mouseenter', () => {
            card.style.transform = 'translateY(-2px)';
        });
        
        card.addEventListener('mouseleave', () => {
            card.style.transform = 'translateY(0)';
        });
    });

    // Notification badge pulse
    const notificationBadge = document.querySelector('.animate-pulse');
    if (notificationBadge) {
        setInterval(() => {
            notificationBadge.style.opacity = notificationBadge.style.opacity === '0.5' ? '1' : '0.5';
        }, 1000);
    }

    // Theme toggle (placeholder for future implementation)
    const themeToggle = document.querySelector('[data-theme-toggle]');
    if (themeToggle) {
        themeToggle.addEventListener('click', () => {
            document.documentElement.classList.toggle('dark');
        });
    }

    // Smooth scroll for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });

    // Keyboard shortcuts
    document.addEventListener('keydown', (e) => {
        // Cmd/Ctrl + K for search
        if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
            e.preventDefault();
            searchInput?.focus();
        }
        
        // Escape to close mobile menu
        if (e.key === 'Escape' && sidebar?.classList.contains('open')) {
            sidebar.classList.remove('open');
        }
    });

    // Real-time clock update
    const updateTime = () => {
        const timeElements = document.querySelectorAll('[data-time]');
        const now = new Date();
        const timeString = now.toLocaleTimeString('en-US', {
            hour: '2-digit',
            minute: '2-digit'
        });
        
        timeElements.forEach(el => {
            el.textContent = timeString;
        });
    };

    setInterval(updateTime, 1000);
    updateTime();

    // Intersection Observer for lazy loading animations
    const observerOptions = {
        root: null,
        rootMargin: '0px',
        threshold: 0.1
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('opacity-100', 'translate-y-0');
                entry.target.classList.remove('opacity-0', 'translate-y-4');
            }
        });
    }, observerOptions);

    document.querySelectorAll('.animate-on-scroll').forEach(el => {
        el.classList.add('opacity-0', 'translate-y-4', 'transition-all', 'duration-500');
        observer.observe(el);
    });

    console.log('🌌 Nebula Nexus Dashboard initialized');
});